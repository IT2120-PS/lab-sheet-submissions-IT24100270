# Import dataset
data <- read.table("DATA 4.txt", header = TRUE)

# View data
print(data)

# Variables:
# X1 = Team Attendance (Ratio scale, quantitative, continuous)
# X2 = Team Salary (Ratio scale, quantitative, continuous)
# X3 = Years since team owned stadium (Ratio scale, quantitative, discrete)

# Boxplot
boxplot(data$X1, main="Boxplot of Team Attendance (X1)")
boxplot(data$X2, main="Boxplot of Team Salary (X2)")
boxplot(data$X3, main="Boxplot of Years (X3)")

# Histograms
hist(data$X1, main="Histogram of Attendance", col="lightblue")
hist(data$X2, main="Histogram of Salary", col="lightgreen")
hist(data$X3, main="Histogram of Years", col="lightpink")

# Stem-and-leaf plots
stem(data$X1)
stem(data$X2)
stem(data$X3)

# Summary statistics
mean(data$X1); median(data$X1); sd(data$X1)
mean(data$X2); median(data$X2); sd(data$X2)
mean(data$X3); median(data$X3); sd(data$X3)

# Quantiles
quantile(data$X1, c(0.25, 0.75))
quantile(data$X2, c(0.25, 0.75))
quantile(data$X3, c(0.25, 0.75))

# Interquartile Range
IQR(data$X1)
IQR(data$X2)
IQR(data$X3)

# Mode function
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

getmode(data$X3)

# Outlier detection function
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)  # First Quartile
  Q3 <- quantile(x, 0.75)  # Third Quartile
  IQR <- Q3 - Q1           # Interquartile Range
  
  lower <- Q1 - 1.5 * IQR  # Lower bound for outliers
  upper <- Q3 + 1.5 * IQR  # Upper bound for outliers
  
  # Return outliers
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

# Find outliers in each variable
find_outliers(data$X1)
find_outliers(data$X2)
find_outliers(data$X3)

